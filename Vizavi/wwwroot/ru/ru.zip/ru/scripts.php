<script src="/ru/assets/scripts/vendor.js"></script>
<script src="/ru/assets/scripts/app.js?noCache30"></script>